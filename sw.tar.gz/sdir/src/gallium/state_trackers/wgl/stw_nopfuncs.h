

#ifndef STW_NOPFUNCS_H
#define STW_NOPFUNCS_H


PROC
stw_get_nop_function(const char *name);


#endif /* STW_NOPFUNCS_H */
